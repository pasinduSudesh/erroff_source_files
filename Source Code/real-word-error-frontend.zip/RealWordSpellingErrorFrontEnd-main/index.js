const popperJs = require('@popperjs/core')
const fs = require('fs');
require('isomorphic-fetch');

var executed = false;
var splittedText; //this is str value
var incorrectList;
var correctList;
var timeout = null; // Init a timeout variable to be used below
var serverUrl = 'https://34.66.4.135.nip.io/'

window.checkSpell = async function () {
  console.log("inside checkspell");

  window.splittedText = document.getElementById("TextToCheck").value;
  if ((typeof window.splittedText === 'undefined') || (window.splittedText == null) || (window.splittedText.trim() == '')){
    alert("Please enter text!");
  }else{
    await window.retrieveAutoCorrections();
    window.suggestHandle(window.splittedText);
  }
}

window.suggestHandle = async function (inputText) {
  document.getElementById("output").innerHTML = `<div id="loader" class="center" style= "display : block"></div>`
  console.log("inside suggestHandle");
  let inputList = inputText.split(" ")
  
  for (const index in inputList) {
    let word = inputList[index]
    if(word.includes(".")){
      word = word.replace(".", "");
      if (window.incorrectList.includes(word)){
        position = window.incorrectList.indexOf(word);
        inputList[index] = window.correctList[position]+".";
      }
    }else if (window.incorrectList.includes(word)){
      position = window.incorrectList.indexOf(word);
      inputList[index] = window.correctList[position];
    }else{
      continue
    }
  }

  console.log("check :: ", inputList.join(' '));
  const postData = {
    splittedText: inputList.join(' '),
  };
  
  await fetch(serverUrl, {
    "method": "post",
    "headers": {
      "Content-Type": "application/json"
    },
    "body": JSON.stringify(postData)
  })
  .then(data=>data.json())
  .then(response => {
    let suggestionList = response.wordPredictions
    inputList = response.input.split(" ")

    for (let i=0; i<suggestionList.length;i++){
      let index = suggestionList[i]["index"]
      let originalWord = suggestionList[i]["word"]
      let suggestions = suggestionList[i]["suggestions"]

      if (suggestionList[i]["errorLevel"] === 1){
        inputList[index] = `<span class="error-word" id="w_${index}" onClick="window.popupShow( ${index}, '${originalWord}', '${suggestions}')">${inputList[index]}</span>`
      }else if (suggestionList[i]["errorLevel"] === 2){
        inputList[index] = `<span class="suggestion-word" id="w_${index}" onClick="window.popupShow( ${index}, '${originalWord}', '${suggestions}')">${inputList[index]}</span>`
      }
    }

    let outputText = inputList.join(" ");
    //window.changeLoadingScreen();
    document.getElementById("output").innerHTML = outputText;
  })
  .catch(err => console.error("double check the server url"));
}

window.popupShow = function (index,originalWord, suggestString){
  console.log("inside popupShow");

  let suggestions = suggestString.split(",");
  if (suggestions.length > 0 && suggestions[0] != ''){
    let output_list = "<ul class='suggetion'>"
    for (const word of suggestions) {
      output_list += `<li class='list-items' onClick="window.updateText(${index},'${word}')"><span>${word}</span></li>`
    }
    output_list + "</ul>"
  
    let targetObj = document.getElementById('w_'+ index)
    let tooltip = document.getElementById('popup')
    tooltip.innerHTML = output_list
    popperJs.createPopper(targetObj,tooltip,{
        placement: 'bottom',
    });
  }
}

window.updateText = function (index, word){
  console.log("inside updateText");
  
  let inputList = window.splittedText.split(" ")
  inputList[index] = word;
  window.splittedText = inputList.join(" ");
  
  window.suggestHandle(window.splittedText);

  document.getElementById('popup').innerHTML = "";
}

window.loadText = async function (){
  console.log("inside loadText")
  var input = document.getElementById("fileinput");
  input.addEventListener("change", await loadFile(), false);

  function loadFile() {
    var file, fr;
    console.log("inside loadFile")

    if (typeof window.FileReader !== 'function') {
      console.log("0")
      alert("The file API isn't supported on this browser yet.");
      return;
    }

    if (!input.files) {
      console.log("1")
      alert("This browser doesn't seem to support the `files` property of file inputs.");
    }else if (!input.files[0]) {
      console.log("2")
      alert("Please select a file before clicking 'Load'");
    }else {
      file = input.files[0];
      new Promise((resolve, reject) => {
        fr = new FileReader();
    
        fr.onload = res => {
          resolve(receivedText());
        };
        fr.onerror = err => reject(err);
    
        fr.readAsText(file);
      });
    }
    function receivedText() {
      document.getElementById("TextToCheck").value = fr.result;
    }
  }
}

window.saveAsFile= function (){
  console.log("inside saveAsFile")
  
  const outputText = document.getElementById("output").textContent;

  if ((typeof outputText === 'undefined') || (outputText == null) || (outputText.trim() == '')){
    return alert("No Text to Save!");
  }else{
    // Convert the text to BLOB.
    const textToBLOB = new Blob([outputText], { type: 'text/plain' });
    const sFileName = 'results.txt'; // The file to save the data.
  
    let newLink = document.createElement("a");
    newLink.download = sFileName;
  
    if (window.webkitURL != null) {
        newLink.href = window.webkitURL.createObjectURL(textToBLOB);
    }
    else {
        newLink.href = window.URL.createObjectURL(textToBLOB);
        newLink.style.display = "none";
        document.body.appendChild(newLink);
    }
  
    newLink.click();
  }
}

window.retrieveAutoCorrections = async function() {
  if (!executed) {
    console.log("inside retrieveAutoCorrections");
    try{
      executed = true;
      const data = await fs.readFileSync("./autocorrectionWords.txt", 'utf8')
      let autoList = data.split('\n');
      let inCorList = [];
      let corList = [];
      for (const index in autoList) {
          let oneSet = autoList[index]
          let incorrect = oneSet.split(':')[0];
          let correct = oneSet.split(':')[1];
          inCorList.push(incorrect);
          corList.push(correct);
      }
      window.incorrectList = inCorList;
      window.correctList = corList;
    }catch(err){
      console.log(err);
    }
  };
};

$(document).ready(function() {
        
  // Initialize the tooltip.
  $('#copy-button').tooltip();

  $('#copy-button').bind('click', function() {
      var r = document.createRange();
      r.selectNode(document.getElementById("output"));
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(r);
      document.execCommand('copy');
      window.getSelection().removeAllRanges();
      try {
          var success = document.execCommand('copy');
          if (success) {
              $('#copy-button').trigger('copied', ['Copied!']);
          } else {
              $('#copy-button').trigger('copied', ['Copy with Ctrl-c']);
          }
      } catch (err) {
          $('#copy-button').trigger('copied', ['Copy with Ctrl-c']);
      }
  });

  $('#copy-button').bind('copied', function(event, message) {
      $(this).attr('title', message)
          .tooltip('_fixTitle')
          .tooltip('show')
          .attr('title', "Copy to Clipboard")
          .tooltip('_fixTitle');
  });
});

document.getElementById('output').addEventListener('keyup', function (e) {
    clearTimeout(timeout);

    // Make a new timeout set to go off in 1000ms (1 second)
    timeout = setTimeout(function () {
        window.splittedText = document.getElementById('output').innerText
        console.log(window.splittedText);
        window.suggestHandle(window.splittedText)
    }, 1000);
});

window.getFullyAutoCorrectedSentence = async function (){
  console.log("inside getFullyAutoCorrectedSentence");

  window.splittedText = document.getElementById("TextToCheck").value;
  
  if(document.getElementById("output").innerText.trim() == "" || typeof document.getElementById("output").innerText === 'undefined'){
    console.log("splitted text ::", window.splittedText);
    if ((window.splittedText === undefined) || (window.splittedText == null) || (window.splittedText == '')){
      return alert("Please enter text!");
    }
  }else{
    window.splittedText = document.getElementById("output").innerText;
  }

  await window.retrieveAutoCorrections();

  let inputText = window.splittedText;

  document.getElementById("output").innerHTML = `<div id="loader" class="center" style= "display : block"></div>`

  let inputList = inputText.split(" ")
  
  for (const index in inputList) {
    let word = inputList[index]
    if(word.includes(".")){
      word = word.replace(".", "");
      if (window.incorrectList.includes(word)){
        position = window.incorrectList.indexOf(word);
        inputList[index] = window.correctList[position]+".";
      }
    }else if (window.incorrectList.includes(word)){
      position = window.incorrectList.indexOf(word);
      inputList[index] = window.correctList[position];
    }else{
      continue
    }
  }

  console.log("check :: ", inputList.join(' '));
  const postData = {
    splittedText: inputList.join(' '),
  };
  
  await fetch(serverUrl, {
    "method": "post",
    "headers": {
      "Content-Type": "application/json"
    },
    "body": JSON.stringify(postData)
  })
  .then(data=>data.json())
  .then(response => {
    let suggestionList = response.wordPredictions
    inputList = response.predicted.split(" ")

    for (let i=0; i<suggestionList.length;i++){
      let index = suggestionList[i]["index"]
      let originalWord = suggestionList[i]["word"]
      let suggestions = suggestionList[i]["suggestions"]

      //remove auto corrected word from the suggestions list
      var Index = suggestions.indexOf(inputList[index]);
      if (Index !== -1) {
        suggestions.splice(Index, 1);
      }

      if(suggestions == undefined || suggestions == null){
        suggestions = [];
      }
      
      if (suggestionList[i]["errorLevel"] === 1){
        inputList[index] = `<span class="correct-word" id="w_${index}" onClick="window.popupShow( ${index}, '${originalWord}', '${suggestions}')">${inputList[index]}</span>`
      }  
      //  else if (suggestionList[i]["errorLevel"] === 2){
      //   inputList[index] = `<span class="correct-word" id="w_${index}" onClick="window.popupShow( ${index}, '${originalWord}', '${suggestions}')">${inputList[index]}</span>`
      // }
    }

    let outputText = inputList.join(" ");
    //window.changeLoadingScreen();
    document.getElementById("output").innerHTML = outputText;
  })
  .catch(err => console.error("double check the server url :: "+ err));
}

window.clearCell = function (){
  document.getElementById("TextToCheck").value = '';
  document.getElementById("output").innerHTML = '';
  window.splittedText = "";
}
